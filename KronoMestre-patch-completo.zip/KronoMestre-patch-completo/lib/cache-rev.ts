/**
 * Coerência de cache entre instâncias do servidor (e sinal de "mudou algo" para os clientes).
 *
 * PROBLEMA: cada instância tem o próprio cache em memória. Com TTL longo (economia de leituras), uma
 * gravação feita na instância A deixaria a instância B servindo dados velhos até o TTL vencer.
 *
 * SOLUÇÃO: um documento minúsculo por tenant (tenants/{owner}/meta/cache_rev) guarda contadores
 *   r.{coleção}.{idDaInstância} = nº de gravações feitas por aquela instância.
 * - Cada instância só incrementa o PRÓPRIO contador (sem transação, sem contenção).
 * - Uma instância descarta seu cache de uma coleção quando o contador de OUTRA instância mudou.
 * - O doc é lido no máx. 1x a cada READ_THROTTLE_MS por tenant (por instância), e as gravações são
 *   agrupadas (debounce) em 1 escrita a cada FLUSH_DELAY_MS.
 * Custo típico: ~180 leituras/hora por instância ativa, contra milhares de uma coleção relida.
 * Se o Firestore falhar, o comportamento cai de volta para TTL puro (nunca quebra a requisição).
 */

export type RevBackend = {
  readMeta(owner: string): Promise<Record<string, Record<string, number>> | null>;
  flush(owner: string, increments: Record<string, number>, instanceId: string): Promise<void>;
};

const TRACKED = ['students', 'activities', 'messages', 'library', 'second_teachers', 'atestados_rad', 'rco_emissions'] as const;
export type TrackedCollection = (typeof TRACKED)[number];

/** Converte uma chave de cache (ex.: "activities_UID") em { collection, owner }. Chaves não rastreadas → null. */
export function parseTrackedKey(key: string): { collection: TrackedCollection; owner: string } | null {
  // ordem importa: prefixos mais longos primeiro
  const sorted = [...TRACKED].sort((a, b) => b.length - a.length);
  for (const c of sorted) {
    if (key.startsWith(c + '_')) {
      const owner = key.slice(c.length + 1);
      if (owner) return { collection: c, owner };
    }
  }
  return null;
}

export class RevTracker {
  private remote = new Map<string, { at: number; data: Record<string, Record<string, number>> }>();
  private inflightRead = new Map<string, Promise<void>>();
  private own = new Map<string, number>(); // `${owner}|${collection}` → contagem local (imediata)
  private pending = new Map<string, Record<string, number>>();
  private timers = new Map<string, ReturnType<typeof setTimeout>>();

  constructor(
    public readonly instanceId: string,
    private backend: RevBackend,
    private opts: { readThrottleMs: number; flushDelayMs: number } = { readThrottleMs: 20_000, flushDelayMs: 1_500 }
  ) {}

  private async refresh(owner: string): Promise<void> {
    const cached = this.remote.get(owner);
    if (cached && Date.now() - cached.at < this.opts.readThrottleMs) return;

    let p = this.inflightRead.get(owner);
    if (!p) {
      p = (async () => {
        try {
          const data = await this.backend.readMeta(owner);
          this.remote.set(owner, { at: Date.now(), data: data || {} });
        } catch {
          // Falha ao ler (cota/rede): mantém o que já se sabia e tenta de novo só depois do throttle
          this.remote.set(owner, { at: Date.now(), data: cached?.data || {} });
        } finally {
          this.inflightRead.delete(owner);
        }
      })();
      this.inflightRead.set(owner, p);
    }
    await p;
  }

  /** Soma dos contadores de TODAS as outras instâncias para a coleção (muda quando outra instância grava). */
  async othersRev(owner: string, collection: string): Promise<number> {
    await this.refresh(owner);
    const perInstance = this.remote.get(owner)?.data?.[collection] || {};
    let sum = 0;
    for (const [inst, n] of Object.entries(perInstance)) {
      if (inst !== this.instanceId) sum += Number(n) || 0;
    }
    return sum;
  }

  /** Revisão total (todas as instâncias + gravações locais ainda não enviadas): é o que o cliente observa. */
  async totalRev(owner: string, collection: string): Promise<number> {
    const others = await this.othersRev(owner, collection);
    const remoteOwn = Number(this.remote.get(owner)?.data?.[collection]?.[this.instanceId]) || 0;
    const localOwn = this.own.get(`${owner}|${collection}`) || 0;
    return others + Math.max(remoteOwn, localOwn);
  }

  /** Registra que ESTA instância gravou na coleção. Agrupa e envia 1 incremento por janela. */
  noteWrite(owner: string, collection: string): void {
    const k = `${owner}|${collection}`;
    this.own.set(k, (this.own.get(k) || 0) + 1);

    const p = this.pending.get(owner) || {};
    p[collection] = (p[collection] || 0) + 1;
    this.pending.set(owner, p);

    if (this.timers.has(owner)) return;
    const t = setTimeout(() => {
      this.timers.delete(owner);
      void this.flushNow(owner);
    }, this.opts.flushDelayMs);
    (t as any).unref?.();
    this.timers.set(owner, t);
  }

  async flushNow(owner: string): Promise<void> {
    const inc = this.pending.get(owner);
    if (!inc || Object.keys(inc).length === 0) return;
    this.pending.delete(owner);
    try {
      await this.backend.flush(owner, inc, this.instanceId);
    } catch {
      // Falhou: devolve para tentar na próxima janela (sem perder o sinal para outras instâncias)
      const again = this.pending.get(owner) || {};
      for (const [c, n] of Object.entries(inc)) again[c] = (again[c] || 0) + n;
      this.pending.set(owner, again);
    }
  }
}

/** Backend real: Firestore via firebase-admin, importado só quando necessário. */
export function createFirestoreBackend(): RevBackend {
  return {
    async readMeta(owner) {
      const { getAdminDb } = await import('./firebase-admin');
      const snap = await getAdminDb().collection('tenants').doc(owner).collection('meta').doc('cache_rev').get();
      return (snap.exists ? (snap.data()?.r as any) : null) || null;
    },
    async flush(owner, increments, instanceId) {
      const { getAdminDb } = await import('./firebase-admin');
      const { FieldValue } = await import('firebase-admin/firestore');
      const r: Record<string, any> = {};
      for (const [c, n] of Object.entries(increments)) r[c] = { [instanceId]: FieldValue.increment(n) };
      await getAdminDb().collection('tenants').doc(owner).collection('meta').doc('cache_rev').set({ r, updatedAt: new Date().toISOString() }, { merge: true });
    },
  };
}
