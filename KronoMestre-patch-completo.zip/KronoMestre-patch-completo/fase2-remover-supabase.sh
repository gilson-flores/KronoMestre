#!/usr/bin/env bash
# FASE 2 - Remoção definitiva do Supabase.
# Rode na raiz do projeto SOMENTE DEPOIS de:
#   1) executar "Importar Supabase -> Firestore" na aba Backup (admin), e
#   2) conferir o inventário: abra /api/admin/migrate-supabase-to-firestore (GET, logado como admin)
#      e confirmar que, em cada tabela, "firestore" >= "supabase".
# Recomendado: crie uma branch/backup antes (git checkout -b remove-supabase).
set -euo pipefail

echo "Este script APAGA arquivos do Supabase e desinstala @supabase/supabase-js."
read -r -p "Digite REMOVER para continuar: " ans
[ "$ans" = "REMOVER" ] || { echo "Cancelado."; exit 1; }

rm -f lib/supabase.ts lib/supabase-admin.ts
rm -rf app/api/admin/migrate-supabase-to-firestore app/api/admin/pull-archives
rm -rf supabase .github/workflows/supabase-migrations.yml

python3 - <<'PY'
import re, pathlib

# 1) Remove da tela de Backup o bloco da ferramenta de migração
p = pathlib.Path('components/views/BackupView.tsx')
s = p.read_text(encoding='utf-8')
a = s.find('{/* SEÇÃO ADMIN SUPREMO: MIGRAÇÃO SUPABASE -> FIRESTORE */}')
b = s.find('{/* SEÇÃO 2: ARQUIVAR VÍNCULO ATUAL')
if a != -1 and b != -1 and a < b:
    # recua até o início da linha para manter a indentação limpa
    a = s.rfind('\n', 0, a) + 1
    b = s.rfind('\n', 0, b) + 1
    p.write_text(s[:a] + s[b:], encoding='utf-8')
    print('BackupView: bloco de migração removido')
else:
    print('BackupView: marcadores não encontrados (remova o bloco manualmente)')

# 2) .env.example: tira variáveis/comentários do Supabase, mantém AUTH_JWT_SECRET e adiciona MCP_TENANT_ID
p = pathlib.Path('.env.example')
lines = p.read_text(encoding='utf-8').splitlines()
out = [l for l in lines if 'SUPABASE' not in l.upper()]
txt = re.sub(r'\n{3,}', '\n\n', '\n'.join(out)).strip() + '\n'
if 'AUTH_JWT_SECRET' not in txt:
    txt += '\nAUTH_JWT_SECRET=\n'
if 'MCP_TENANT_ID' not in txt:
    txt += '\n# UID do professor titular usado pelo servidor MCP (npm run mcp)\nMCP_TENANT_ID=\n'
p.write_text(txt, encoding='utf-8')
print('.env.example atualizado')
PY

if [ "${SKIP_NPM:-0}" != "1" ]; then
  npm uninstall @supabase/supabase-js
fi

echo
echo "Concluído. Faltam 2 passos manuais:"
echo "  1) Remova NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY e SUPABASE_SERVICE_ROLE_KEY do painel/segredos da hospedagem."
echo "  2) Rode 'npm run build' para confirmar que compila sem referências ao Supabase."
