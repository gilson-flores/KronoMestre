import { NextRequest, NextResponse } from 'next/server';
import { getSessionFromRequest } from '@/lib/auth-server';
import { serverCache } from '@/lib/server-cache';

export const dynamic = 'force-dynamic';

// Versão do build embutida na compilação (mesmo valor que o cliente carrega no bundle)
const SERVER_BUILD_ID = process.env.NEXT_PUBLIC_BUILD_ID || 'dev';

const COLLECTIONS = ['students', 'activities', 'messages', 'library', 'second_teachers', 'atestados_rad'];

/**
 * Endpoint leve para o cliente saber se ALGO mudou desde a última verificação.
 * - Não lê coleções: usa só os contadores de revisão (1 leitura de doc minúsculo, no máx. a cada 20s por instância,
 *   não importa quantos alunos perguntem).
 * - Devolve também o ID do build, para o cliente detectar que está rodando uma versão antiga do app.
 */
export async function GET(req: NextRequest) {
  try {
    const session = await getSessionFromRequest(req);
    if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 });

    const owner = session.ownerTeacherId || session.sub;
    const rev = await serverCache.getRevision(owner, COLLECTIONS);
    return NextResponse.json({ build: SERVER_BUILD_ID, rev });
  } catch (err: any) {
    // Nunca derruba o cliente por causa disto: sem revisão, o cliente apenas não atualiza agora
    return NextResponse.json({ build: SERVER_BUILD_ID, rev: {} });
  }
}
