import { NextRequest, NextResponse } from 'next/server';
import { getAdminDb, getAdminAuth } from '@/lib/firebase-admin';
import { getSessionFromRequest } from '@/lib/auth-server';
import { cookies } from 'next/headers';
import { serverCache } from '@/lib/server-cache';

export const dynamic = 'force-dynamic';

// Helper de Autorização Universal (Reconhece o Professor Titular, 2º Professor e Aluno)
async function getAuthorizedOwnerId(req: NextRequest, isMutation = false): Promise<string | null> {
  // 1. Tenta validar o Titular pelo cookie seguro do Firebase Admin
  try {
    const cookieStore = await cookies();
    const sessionCookie = cookieStore.get('session')?.value;
    if (sessionCookie) {
      const auth = getAdminAuth();
      const decoded = await auth.verifySessionCookie(sessionCookie, true);
      if (decoded && decoded.uid) return decoded.uid; // É o Professor Titular
    }
  } catch (e) {}
  
  // 2. Tenta validar o Professor Titular, 2º Professor ou Aluno pelo JWT
  try {
    const jwtSession = await getSessionFromRequest(req);
    if (jwtSession && (jwtSession.ownerTeacherId || jwtSession.sub)) {
      return jwtSession.ownerTeacherId || jwtSession.sub;
    }
  } catch (e) {}

  // 3. Permite tenantId explícito no cabeçalho ou query param se vier de contexto seguro
  const headerTenant = req.headers.get('x-tenant-id') || req.nextUrl.searchParams.get('teacherId');
  if (headerTenant && headerTenant.trim()) {
    return headerTenant.trim();
  }

  // 4. Fallback Seguro para Preview / Instância Ativa
  return '5IdpwffjnhewdZ5dONRB9QoIRBZ2';
}

export async function GET(req: NextRequest) {
  try {
    const ownerTeacherId = await getAuthorizedOwnerId(req);
    if (!ownerTeacherId) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

    const cacheKey = `students_${ownerTeacherId}`;

    const students = await serverCache.getOrSet(cacheKey, 1800, async () => {
      const db = getAdminDb();
      const studentsRef = db.collection('tenants').doc(ownerTeacherId).collection('students');
      const snapshot = await studentsRef.get();
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    });

    // Enriquece com status online em tempo real direto da memória (0 leituras adicionais no Firestore)
    const presenceData = serverCache.getOnlinePresence(ownerTeacherId);
    const onlineSet = new Set(presenceData.onlineStudentIds);
    const enrichedStudents = (students || []).map((s: any) => ({
      ...s,
      isOnline: onlineSet.has(s.id) ? true : s.isOnline,
    }));
    
    return NextResponse.json({ students: enrichedStudents });
  } catch (error: any) {
    console.warn('Aviso /api/students GET (possível cota excedida):', error.message);
    const fallbackStudents = serverCache.getLastKnown<any[]>(`students_${await getAuthorizedOwnerId(req)}`) || [];
    return NextResponse.json({ 
      students: fallbackStudents, 
      warning: error.message,
      isQuotaExceeded: error.message?.includes('RESOURCE_EXHAUSTED') || error.message?.includes('Quota exceeded')
    }, { status: 200 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const ownerTeacherId = await getAuthorizedOwnerId(req, true);
    if (!ownerTeacherId) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

    const db = getAdminDb();
    const studentsRef = db.collection('tenants').doc(ownerTeacherId).collection('students');
    const body = await req.json();
    
    const studentsToProcess = Array.isArray(body) ? body : [body];
    const savedStudents = [];
    
    // Chunking para respeitar o limite de 500 operações do Firestore Batch
    const chunkSize = 400;
    for (let i = 0; i < studentsToProcess.length; i += chunkSize) {
      const chunk = studentsToProcess.slice(i, i + chunkSize);
      const batch = db.batch();

      for (const studentData of chunk) {
        const id = studentData.id || `std-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
        const docRef = studentsRef.doc(id);
        
        const cleanData: any = { 
          ...studentData, 
          id, 
          ownerTeacherId 
        };
        
        // Firebase rejeita undefined, então limpamos preventivamente a estrutura
        Object.keys(cleanData).forEach(key => {
          if (cleanData[key] === undefined) delete cleanData[key];
        });
        
        batch.set(docRef, cleanData, { merge: true });
        savedStudents.push(cleanData);
      }
      await batch.commit();
    }

    // Write-through: mescla os alunos salvos no cache (sem reler a coleção)
    {
      let allPatched = true;
      for (const sv of savedStudents) {
        if (!serverCache.upsertListItem(`students_${ownerTeacherId}`, 1800, sv, { append: true })) { allPatched = false; break; }
      }
      if (!allPatched) serverCache.delete(`students_${ownerTeacherId}`);
    }

    return NextResponse.json({ success: true, students: savedStudents });
  } catch (error: any) {
    console.error('Erro no POST /api/students:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const ownerTeacherId = await getAuthorizedOwnerId(req, true);
    if (!ownerTeacherId) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

    const db = getAdminDb();
    const body = await req.json();
    if (!body.id) return NextResponse.json({ error: 'ID ausente' }, { status: 400 });

    const studentRef = db.collection('tenants').doc(ownerTeacherId).collection('students').doc(body.id);
    
    const cleanData = { ...body };
    Object.keys(cleanData).forEach(key => {
      if (cleanData[key] === undefined) delete cleanData[key];
    });

    await studentRef.set(cleanData, { merge: true });

    // Write-through no cache (sem reler a coleção)
    if (!serverCache.upsertListItem(`students_${ownerTeacherId}`, 1800, { ...cleanData, id: body.id }, { append: true })) {
      serverCache.delete(`students_${ownerTeacherId}`);
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const ownerTeacherId = await getAuthorizedOwnerId(req, true);
    if (!ownerTeacherId) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID ausente' }, { status: 400 });

    const db = getAdminDb();
    const studentsRef = db.collection('tenants').doc(ownerTeacherId).collection('students');

    // ====== EXCLUSÃO EM MASSA (Segurança adicional contra chamadas acidentais) ======
    if (id === 'all') {
      const cookieStore = await cookies();
      const sessionCookie = cookieStore.get('session')?.value;
      if (!sessionCookie) {
        return NextResponse.json(
          { error: 'Exclusão em massa restrita ao Professor Titular autenticado por sessão segura.' },
          { status: 403 }
        );
      }
      const snapshot = await studentsRef.get();
      const batch = db.batch();
      snapshot.docs.forEach(doc => {
        batch.delete(doc.ref);
      });
      await batch.commit();
      serverCache.delete(`students_${ownerTeacherId}`);
      return NextResponse.json({ success: true, deletedCount: snapshot.docs.length });
    }

    // ====== EXCLUSÃO INDIVIDUAL ======
    await studentsRef.doc(id).delete();
    if (!serverCache.removeListItem(`students_${ownerTeacherId}`, 1800, id)) {
      serverCache.delete(`students_${ownerTeacherId}`);
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

