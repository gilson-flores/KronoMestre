'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

const CLIENT_BUILD_ID = process.env.NEXT_PUBLIC_BUILD_ID || '';
const MIN_GAP_MS = 20_000;          // nunca pergunta ao servidor mais de 1x a cada 20s
const POLL_MS = 120_000;            // verificação periódica enquanto a aba está visível

/**
 * Mantém o app "fresco" SEM consumir leituras do Firestore:
 *  - pergunta a /api/sync-state (contadores de revisão em memória) quando a aba volta ao foco,
 *    quando a internet volta e a cada ~2 min com a aba visível;
 *  - se alguma coleção mudou desde a última verificação, chama onChanged([...coleções]);
 *  - se o servidor está num build diferente do que está rodando na aba, liga updateAvailable.
 */
export function useFreshness(opts: { enabled: boolean; onChanged: (changed: string[]) => void }) {
  const { enabled, onChanged } = opts;
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const lastRevRef = useRef<Record<string, number> | null>(null);
  const lastCheckRef = useRef(0);
  const onChangedRef = useRef(onChanged);
  onChangedRef.current = onChanged;

  const check = useCallback(async (force = false) => {
    const now = Date.now();
    if (!force && now - lastCheckRef.current < MIN_GAP_MS) return;
    lastCheckRef.current = now;

    try {
      const res = await fetch('/api/sync-state', { cache: 'no-store' });
      if (!res.ok) return;
      const state = await res.json();

      if (CLIENT_BUILD_ID && state.build && state.build !== 'dev' && state.build !== CLIENT_BUILD_ID) {
        setUpdateAvailable(true);
      }

      const rev: Record<string, number> = state.rev || {};
      const prev = lastRevRef.current;
      lastRevRef.current = rev;
      if (!prev) return; // primeira leitura só define a linha de base

      const changed = Object.keys(rev).filter((k) => prev[k] !== undefined && prev[k] !== rev[k]);
      if (changed.length > 0) onChangedRef.current(changed);
    } catch {
      // sem rede: tenta de novo no próximo gatilho
    }
  }, []);

  useEffect(() => {
    if (!enabled) {
      lastRevRef.current = null;
      return;
    }

    void check(true);

    const onVisible = () => {
      if (document.visibilityState === 'visible') void check();
    };
    const onOnline = () => void check(true);

    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onVisible);
    window.addEventListener('online', onOnline);
    const timer = setInterval(() => {
      if (document.visibilityState === 'visible') void check();
    }, POLL_MS + Math.random() * 30_000);

    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onVisible);
      window.removeEventListener('online', onOnline);
      clearInterval(timer);
    };
  }, [enabled, check]);

  return { updateAvailable, checkNow: () => check(true) };
}
